package com.biker;

/**
 * Created by nz160 on 14-09-2017.
 */

public interface  OnLoadMoreListener {
    void onLoadMore();
}

