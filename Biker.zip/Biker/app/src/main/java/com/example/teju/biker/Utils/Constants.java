package com.example.teju.biker.Utils;

import android.app.Activity;
import android.support.v4.content.ContextCompat;
import android.view.Window;
import android.view.WindowManager;

import com.example.teju.biker.R;

/**
 * Created by nz160 on 20-09-2017.
 */

public class Constants {
    public  static String regexStr = "[0-9]+";
    public static String regEx = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
    public static String SERVER_URL="http://chouguleeducation.in/biker/api/web/";

}
