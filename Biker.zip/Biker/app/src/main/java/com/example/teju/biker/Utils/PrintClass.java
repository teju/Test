package com.example.teju.biker.Utils;

/**
 * Created by Teju on 19/09/2017.
 */
public class PrintClass {

    public static void printValue(String str,String value){

        System.out.println(str+" "+value);
    }

}
